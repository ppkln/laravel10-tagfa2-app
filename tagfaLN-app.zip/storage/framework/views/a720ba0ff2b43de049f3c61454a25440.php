<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            สวัสดีคุณ <?php echo e(Auth::User()->name); ?> ระดับการทำงาน: <?php echo e(Auth::User()->lv_working); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <div class="container d-flex p-2">
        <div class="products-con">
            <div class="products-item">
                <div class="products-img">
                    <img src="/logo-nueng1.png" >
                </div>
                <div class="products-detail">
                    รายละเอียดสินค้า 1
                </div >
                <div class="products-price">
                    <div class="products-left">
                        ฿3500.00 Baht
                    </div >
                    <div class="products-right">
                        ขายแล้ว 200 ชิ้น
                    </div >
                </div >
            </div>
        </div>
        <div class="products-con">
            <div class="products-item">
                <div class="products-img">
                    <img src="/logo-nueng1.png" >
                </div>
                <div class="products-detail">
                    รายละเอียดสินค้า 2
                </div >
                <div class="products-price">
                    <div class="products-left">
                        ฿3500.00 Baht
                    </div >
                    <div class="products-right">
                        ขายแล้ว 200 ชิ้น
                    </div >
                </div >
            </div>
        </div>
        <div class="products-con">
            <div class="products-item">
                <div class="products-img">
                    <img src="/logo-nueng1.png" >
                </div>
                <div class="products-detail">
                    รายละเอียดสินค้า 3
                </div >
                <div class="products-price">
                    <div class="products-left">
                        ฿3500.00 Baht
                    </div >
                    <div class="products-right">
                        ขายแล้ว 200 ชิ้น
                    </div >
                </div >
            </div>
        </div>
    </div>

    <!-- script of fancybox -->
    <script>
      Fancybox.bind('[data-fancybox="gallery"]', {
        //
      });
    </script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>

<?php /**PATH C:\xampp\htdocs\laravel10-tagfa2-app\resources\views/backend/albumproducts/testAlbum.blade.php ENDPATH**/ ?>