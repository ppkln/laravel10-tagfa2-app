<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            สวัสดีคุณ <?php echo e(Auth::User()->name); ?> ระดับการทำงาน: <?php echo e(Auth::User()->lv_working); ?>

            <?php if(Auth::User()->lv_working < 3): ?> <!-- ตรวจสอบว่าผู้ที่ login มีสิทธิ์ใช้งานระดับไหน -->
                ระดับการทำงาน: <?php echo e(Auth::User()->lv_working); ?>

                <?php echo e(header( "location: /dashboard" )); ?>

                <?php echo e(exit(0)); ?>

            <?php endif; ?>
        </h2>
     <?php $__env->endSlot(); ?>
    <div class="py-12">
        <div class="container my-2">
            <div class="row">
                <div class="col-md-10">
                <?php if($message = Session::get('success')): ?>
                    <div class="alert alert-success">
                        <span class="text-success py-2"><?php echo e($message); ?></span>
                    </div>
                <?php elseif($message = Session::get('unsuccess')): ?>
                    <div class="alert alert-danger">
                        <span class=" py-2"><?php echo e($message); ?></span>
                    </div>
                <?php endif; ?>
                    <div class="card">
                        <div class="card-header text-center text-primary">แบบฟอร์มปรับปรุงข้อมูลโพส</div>
                        <div class="card-body">
                            <form action="<?php echo e(url('/posts/update/'.$postEdit->id)); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="post_title">ชื่อหัวข้อโพส: </label><span class="text-warning"> (ต้องระบุ)</span>
                                    <input type="text" class="form-control" name="post_title" value="<?php echo e($postEdit->post_title); ?>">
                                </div>
                                <?php $__errorArgs = ['post_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger py-2"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <div class="form-group">
                                    <label for="post_description">รายละเอียดโพส:</label><span class="text-warning"> (ต้องระบุ)</span>
                                    <textarea class="form-control" name="post_description" ><?php echo e($postEdit->post_description); ?></textarea>
                                </div>
                                <?php $__errorArgs = ['post_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger py-2"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <div class="form-group">
                                    <input type="hidden" name="Old_img" value="<?php echo e($postEdit->postcover_img); ?>">
                                    <input type="hidden" name="postcover_folder" value="<?php echo e($postEdit->postcover_folder); ?>">
                                    <label for="postcover_img">แก้ไขรูปปกโพส:</label><span class="text-warning"> (เฉพาะไฟล์นามสกุล jpg,jpeg,png เท่านั้น และขนาดไฟล์ไม่เกิน 2 MB.) </span>
                                    <input type="file" class="form-control" id="postcover_img" name="postcover_img" accept="image/jpeg,image/jpg,image/png">
                                    <img src="/posts_img/<?php echo e($postEdit->postcover_folder); ?>/<?php echo e($postEdit->postcover_img); ?>" id="previewImg" alt="" class="mt-2" width="300px">
                                </div>
                                <?php $__errorArgs = ['postcover_img'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger py-2"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <input type="hidden" name="user_id" value="<?php echo e(Auth::User()->id); ?>">
                                <br/>
                                <div>
                                    <span class="text-primary py-2">สถานะแสดงผล: </span>
                                    <?php if($postEdit->publish_status == 1): ?>
                                        <label for="publish_status" class="text-success">แสดงผล  <input class="form-check-input" type="checkbox" name="publish_status" checked></label>
                                    <?php else: ?>
                                    <label for="publish_status"  class="text-danger">ยังไม่แสดงผล  <input class="form-check-input" type="checkbox" name="publish_status"></label>
                                    <?php endif; ?>
                                </div>
                                <div class="text-center">
                                    <input type="submit" class="btn btn-primary" value="ปรับปรุงข้อมูล">
                                </div>
                                <br />
                                <a href="<?php echo e(url('/albumposts/album/'.$postEdit->id)); ?>" class="btn btn-success" >จัดการรูปภาพรายละเอียดโพส</a>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<!-- ชุดคำสั่งสำหรับ preview ภาพที่ผู้ใช้ได้เลือก และเปลี่ยนรูปภาพที่เลือกใหม่ -->
<script>
    let imageInput = document.getElementById('postcover_img');
    let previewImg = document.getElementById('previewImg');
    imageInput.onchange = evt =>{
        const [file] = imageInput.files;
        if(file){
            previewImg.src = URL.createObjectURL(file);
        }
    }
</script>
<?php /**PATH C:\xampp\htdocs\laravel10-tagfa2-app\resources\views/backend/posts/editPost.blade.php ENDPATH**/ ?>