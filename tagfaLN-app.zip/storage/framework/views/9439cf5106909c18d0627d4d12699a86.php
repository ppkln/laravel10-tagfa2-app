<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'TAGFA-TH')); ?></title>
        <link rel="icon" type="image/jpg" sizes="20x20" href="/TAGFA_icon.jpg"/>
        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

        <!-- Scripts CDN Bootstrap 5 -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        <!-- Scripts CDN Bootstrap 5 -->

        <!-- fancybox Gallery โดยผู้พัฒนา -->
        <script src="https://cdn.jsdelivr.net/npm/@fancyapps/ui@5.0/dist/fancybox/fancybox.umd.js"></script>
        <link
            rel="stylesheet"
            href="https://cdn.jsdelivr.net/npm/@fancyapps/ui@5.0/dist/fancybox/fancybox.css"
        />
        <!-- End fancybox Gallery-->



        <!-- Styles -->
        <?php echo \Livewire\Livewire::styles(); ?>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
        <!-- Gallery script โดยผู้พัฒนา-->
        <style >
        *{
            margin:0;
            padding:0;
            box-sizing: border-box;
        }
        .container-album {
            max-width:1028px;
            margin:0 auto;
        }
        .products-con{
            display:grid;
            grid-template-columns: repeat(auto-fill,minmax(180px,1fr));
            grid-gap:0.5rem;
        }
        .products-item {
            box-shadow: 0 0 5px rgba(0,0,0,0.3);
            transition:0.3s;
        }
        .products-item:hover {
            border: 1px solid orange;
        }
        .products-detail {
            padding:0.5rem;
        }
        .products-img img{
            width:100%;
        }
        .products-price {
            padding: 1rem;
            align-items: center;
            justify-content: space-between;
        }
        .products-left span{
            font-size: 6px;
        }
        .products-right span{
            font-size: 6px;
        }


        .posts-con{
            display:grid;
            grid-template-columns: repeat(auto-fill,minmax(180px,1fr));
            grid-gap:0.5rem;
        }
        .posts-item {
            box-shadow: 0 0 5px rgba(0,0,0,0.3);
            transition:0.3s;
        }
        .posts-item:hover {
            border: 1px solid orange;
        }
        .posts-detail {
            padding:0.5rem;
        }
        .posts-img img{
            width:100%;
        }
        .posts-price {
            padding: 1rem;
            align-items: center;
            justify-content: space-between;
        }
        .posts-left span{
            font-size: 6px;
        }
        .posts-right span{
            font-size: 6px;
        }

        </style>


    </head>
    <body class="font-sans antialiased">
        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.banner','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('banner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

        <div class="min-h-screen bg-gray-100">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('navigation-menu')->html();
} elseif ($_instance->childHasBeenRendered('cfkHuBF')) {
    $componentId = $_instance->getRenderedChildComponentId('cfkHuBF');
    $componentTag = $_instance->getRenderedChildComponentTagName('cfkHuBF');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('cfkHuBF');
} else {
    $response = \Livewire\Livewire::mount('navigation-menu');
    $html = $response->html();
    $_instance->logRenderedChild('cfkHuBF', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

            <!-- Page Heading -->
            <?php if(isset($header)): ?>
                <header class="bg-white shadow">
                    <div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
                        <?php echo e($header); ?>

                    </div>
                </header>
            <?php endif; ?>

            <!-- Page Content -->
            <main>
                <?php echo e($slot); ?>

            </main>
        </div>

        <?php echo $__env->yieldPushContent('modals'); ?>

        <?php echo \Livewire\Livewire::scripts(); ?>



    </body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel10-tagfa2-app\resources\views/layouts/app.blade.php ENDPATH**/ ?>