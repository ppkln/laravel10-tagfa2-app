<style>
        #myBtn {
            display: none;
            position: fixed;
            bottom: 20px;
            right: 30px;
            z-index: 99;
            font-size: 18px;
            border: none;
            outline: none;
            background-color: navy;
            color: white;
            cursor: pointer;
            padding: 15px;
            border-radius: 4px;
            }
            #myBtn:hover {
            background-color: #345;
            }
    </style>
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <button onclick="topFunction()" id="myBtn" title="Go to top">Top</button><!-- ปุ่ม top up-->
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            สวัสดีคุณ <?php echo e(Auth::User()->name); ?> ระดับการทำงาน: <?php echo e(Auth::User()->lv_working); ?>

            <?php if(Auth::User()->lv_working < 3): ?> <!-- ตรวจสอบว่าผู้ที่ login มีสิทธิ์ใช้งานระดับไหน -->
                ระดับการทำงาน: <?php echo e(Auth::User()->lv_working); ?>

                <?php echo e(header( "location: /dashboard" )); ?>

                <?php echo e(exit(0)); ?>

            <?php endif; ?>
        </h2>
     <?php $__env->endSlot(); ?>
    <div class="py-12">
        <div class="container my-2">
            <div class="row">
                <div class="col-lg-10">
                <?php if($message = Session::get('success')): ?>
                    <div class="alert alert-success">
                        <span class="text-success py-2"><?php echo e($message); ?></span>
                    </div>
                <?php elseif($message = Session::get('unsuccess')): ?>
                    <div class="alert alert-danger">
                        <span class=" py-2"><?php echo e($message); ?></span>
                    </div>
                <?php endif; ?>
                    <div class="card">
                        <div class="card-header text-center text-primary"><strong>แบบฟอร์มจัดการรูปภาพโพส</strong></div>
                        <div class="card-body">
                            <form action="<?php echo e(route('albumPostAddImg')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                <div class=" text-left p-1">
                                    <a href="<?php echo e(url('/posts/editNo/'.$post_album->post_no)); ?>" class="btn btn-sm navbar-btn btn-warning" ><< ย้อนกลับปรับปรุงข้อมูลโพส</a>
                                </div>
                                    <input type="hidden" name="post_id" value="<?php echo e($post_album->id); ?>">
                                    <input type="hidden" name="postcover_folder" value="<?php echo e($post_album->postcover_folder); ?>">
                                    <input type="hidden" name="post_no" value="<?php echo e($post_album->post_no); ?>">
                                    <input type="hidden" name="user_id" value="<?php echo e(Auth::User()->id); ?>">
                                    <label class="text-success">รหัสโพส :  </label><span class="text-primary"> <?php echo e($post_album->post_no); ?></span><br/>
                                    <label class="text-success">ชื่อโพส :  </label><span class="text-primary"> <?php echo e($post_album->post_title); ?></span><br/>
                                    <label class="text-danger" >รูปปกโพส:</label>
                                    <img src="/posts_img/<?php echo e($post_album->postcover_folder); ?>/<?php echo e($post_album->postcover_img); ?>" id="previewCoverImg" alt="" class="p-2" style="width: 400px;">
                                    <div class="row">
                                        <div class="mt-2 p-2">
                                            <label class="mt-2 text-primary">เพิ่มรูป: <span class="text-warning"> (รองรับเฉพาะไฟล์นามสกุล jpg,jpeg,png เท่านั้น และไฟล์ขนาดไม่เกินไฟล์ละ 2 MB) </span>
                                                <input type="file" class="form-control my-2" name="album_img[]" accept="image/jpeg,image/jpg,image/png" multiple="multiple">
                                            </label>
                                        </div>
                                        <?php $__errorArgs = ['album_img'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger py-2"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        <br/>
                                    </div>
                                </div>
                                <div class=" text-center p-3 my-3">
                                    <input type="submit" class="btn btn-primary navbar-btn" value="อัพโหลด">
                                </div>
                            </form>
                            <hr>
                            <div class="row">
                                <label class="text-danger p-2" >รูปภาพรายละเอียดโพส: </label>
                            </div>
                            <div class="container-album">
                                <div class="posts-con">
                                    <?php $__currentLoopData = $album_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="posts-item p-2">
                                            <div class="posts-img">
                                                <a class="image"
                                                data-fancybox="gallery"
                                                data-src="/posts_img/<?php echo e($post_album->postcover_folder); ?>/<?php echo e($value->album_no); ?>/<?php echo e($value->img_name); ?>"
                                            >
                                                <img src="/posts_img/<?php echo e($post_album->postcover_folder); ?>/<?php echo e($value->album_no); ?>/<?php echo e($value->img_name); ?>" alt="<?php echo e($value->img_name); ?>"/>
                                            </a>
                                            </div>

                                            <div class="posts-price d-flex">
                                                <div class="posts-left text-primary">
                                                    วันที่บันทึก:
                                                </div >
                                                <div class="posts-right">
                                                    <?php echo e($value->created_at); ?>

                                                </div >
                                            </div >
                                            <div class="posts-detail">
                                                <a href="<?php echo e(url('/albumposts/deleteImg/'.$value->id)); ?>" class="btn btn-sm btn-danger" onclick="return confirm('ยืนยันการลบข้อมูลนี้!!')">ลบ</a>
                                            </div >
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container ">

            </div>
    </div>
    <!-- script of fancybox -->
    <script>
      Fancybox.bind('[data-fancybox="gallery"]', {
        //
      });
    </script>

    <!-- ส่วนของปุ่ม on top -->
    <script>
        let mybutton = document.getElementById("myBtn");
        // When the user scrolls down 20px from the top of the document, show the button
        window.onscroll = function() {scrollFunction()};
        function scrollFunction() {
        if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
            mybutton.style.display = "block";
        } else {
            mybutton.style.display = "none";
        }
        }
        // When the user clicks on the button, scroll to the top of the document
        function topFunction() {
        document.body.scrollTop = 0;
        document.documentElement.scrollTop = 0;
        }
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>

<?php /**PATH C:\xampp\htdocs\laravel10-tagfa2-app\resources\views/backend/albumposts/addimgs.blade.php ENDPATH**/ ?>